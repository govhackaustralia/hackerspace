(function($) {
    $(document).ready(function(){
        $('#judge_comment_button').click(function(){
            $('.custom_error').remove();
            var comment = $('#judge_comment_text').val()
            var nid = $('#judge_comment_text').attr('class')
            if(!comment){
                $('#judge_comment_button').after('<div class="custom_error"><p>Please enter comment.</p></div>')
                return false;
            }
            jQuery.ajax({
                type: 'POST',
                url: '/ajax/judge/comment',
                dataType: 'json',
                data: {'comment': comment, 'time' : jQuery.now(), 'nid': nid},
                beforeSend: function(data) {
                    $('#judge_comment_text').attr('readonly','readonly');
                    $('#judge_comment_button').attr('disabled', 'disabled');
                },
                success: function (data) {

                    if(data.result = 1){
                        alert('Comment saved.');
                        $('#judge_comment_text').remove();
                        $('#judge_comment_button').remove();
                    }
                    else{
                        $('#judge_comment_text').removeAttr('readonly');
                        $('#judge_comment_button').removeAttr('disabled');
                        $('#judge_comment_button').after('<div class="custom_error"><p>Error! please try again.</p></div>')
                    }

                }
            });
        })
    })
})(jQuery);;
(function ($) {

/**
 * Attaches double-click behavior to toggle full path of Krumo elements.
 */
Drupal.behaviors.devel = {
  attach: function (context, settings) {

    // Add hint to footnote
    $('.krumo-footnote .krumo-call').once().before('<img style="vertical-align: middle;" title="Click to expand. Double-click to show path." src="' + settings.basePath + 'misc/help.png"/>');

    var krumo_name = [];
    var krumo_type = [];

    function krumo_traverse(el) {
      krumo_name.push($(el).html());
      krumo_type.push($(el).siblings('em').html().match(/\w*/)[0]);

      if ($(el).closest('.krumo-nest').length > 0) {
        krumo_traverse($(el).closest('.krumo-nest').prev().find('.krumo-name'));
      }
    }

    $('.krumo-child > div:first-child', context).dblclick(
      function(e) {
        if ($(this).find('> .krumo-php-path').length > 0) {
          // Remove path if shown.
          $(this).find('> .krumo-php-path').remove();
        }
        else {
          // Get elements.
          krumo_traverse($(this).find('> a.krumo-name'));

          // Create path.
          var krumo_path_string = '';
          for (var i = krumo_name.length - 1; i >= 0; --i) {
            // Start element.
            if ((krumo_name.length - 1) == i)
              krumo_path_string += '$' + krumo_name[i];

            if (typeof krumo_name[(i-1)] !== 'undefined') {
              if (krumo_type[i] == 'Array') {
                krumo_path_string += "[";
                if (!/^\d*$/.test(krumo_name[(i-1)]))
                  krumo_path_string += "'";
                krumo_path_string += krumo_name[(i-1)];
                if (!/^\d*$/.test(krumo_name[(i-1)]))
                  krumo_path_string += "'";
                krumo_path_string += "]";
              }
              if (krumo_type[i] == 'Object')
                krumo_path_string += '->' + krumo_name[(i-1)];
            }
          }
          $(this).append('<div class="krumo-php-path" style="font-family: Courier, monospace; font-weight: bold;">' + krumo_path_string + '</div>');

          // Reset arrays.
          krumo_name = [];
          krumo_type = [];
        }
      }
    );
  }
};

})(jQuery);
;
